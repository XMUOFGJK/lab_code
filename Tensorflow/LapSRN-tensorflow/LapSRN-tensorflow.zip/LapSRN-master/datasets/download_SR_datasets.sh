#!/bin/bash
wget http://vllab1.ucmerced.edu/~wlai24/LapSRN/results/SR_training_datasets.zip
unzip SR_training_datasets.zip
wget http://vllab1.ucmerced.edu/~wlai24/LapSRN/results/SR_testing_datasets.zip
unzip SR_testing_datasets.zip
